var codropsEvents = {
	'09-16-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'09-20-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'09-25-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',

	'10-08-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'10-10-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'10-15-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'10-19-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',

	'11-12-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'11-18-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'11-20-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',

	'12-05-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'12-09-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'12-28-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'12-11-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'12-26-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'12-14-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',

	'08-23-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'08-06-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'08-11-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>',
	'08-31-2015' : '<a href="http://tympanus.net/codrops/2012/11/23/three-script-updates/" title="Three Script Updates">Three Script Updates</a>'
};